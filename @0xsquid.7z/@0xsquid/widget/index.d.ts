export declare const SquidWidget: ({ config }: import("./widget").AppProps) => JSX.Element;
