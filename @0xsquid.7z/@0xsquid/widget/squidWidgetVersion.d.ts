export declare const SQUID_WIDGET_VERSION = "1.6.7";
