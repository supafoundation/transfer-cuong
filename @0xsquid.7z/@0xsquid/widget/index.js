import { SquidMainWidget } from "./widget";
export const SquidWidget = SquidMainWidget;
//# sourceMappingURL=index.js.map