export const SQUID_WIDGET_VERSION = "1.6.7";
//# sourceMappingURL=squidWidgetVersion.js.map