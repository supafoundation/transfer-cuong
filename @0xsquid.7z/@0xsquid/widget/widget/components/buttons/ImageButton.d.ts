import React from "react";
export interface ImageButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
}
export declare const ImageButton: React.FC<ImageButtonProps>;
