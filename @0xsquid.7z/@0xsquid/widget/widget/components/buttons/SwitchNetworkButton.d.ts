export declare const SwitchNetworkButton: ({ ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) => JSX.Element;
