import type { ButtonHTMLAttributes } from "react";
export declare const SettingsButton: React.FC<ButtonHTMLAttributes<HTMLButtonElement>>;
