export declare const BackButton: ({ ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) => JSX.Element;
