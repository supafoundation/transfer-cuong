export declare const AccountButton: () => JSX.Element;
