import type { TransactionParams } from "../../core/types/transaction";
export declare const ViewTransactionButton: ({ transaction, }: {
    transaction: TransactionParams | undefined;
}) => JSX.Element | null;
