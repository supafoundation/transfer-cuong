export declare const ExpressToggle: ({ fadeOnLoad, allowTransparency, }: {
    fadeOnLoad?: boolean | undefined;
    allowTransparency?: boolean | undefined;
}) => JSX.Element;
