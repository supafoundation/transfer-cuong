export declare const GasToggle: ({ fadeOnLoad, allowTransparency }: {
    fadeOnLoad?: boolean | undefined;
    allowTransparency?: boolean | undefined;
}) => JSX.Element;
