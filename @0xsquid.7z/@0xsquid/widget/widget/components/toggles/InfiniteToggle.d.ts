export declare const InfiniteToggle: ({ fadeOnLoad }: {
    fadeOnLoad?: boolean | undefined;
}) => JSX.Element;
