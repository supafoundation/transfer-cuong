export declare const PoweredBy: () => JSX.Element;
