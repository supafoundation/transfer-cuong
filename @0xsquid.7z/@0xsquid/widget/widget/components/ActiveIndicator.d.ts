export declare const ActiveIndicator: () => JSX.Element;
