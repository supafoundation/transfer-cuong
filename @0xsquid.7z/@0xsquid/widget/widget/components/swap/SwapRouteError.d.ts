export declare const SwapRouteError: ({ error }: {
    error: any;
}) => JSX.Element;
