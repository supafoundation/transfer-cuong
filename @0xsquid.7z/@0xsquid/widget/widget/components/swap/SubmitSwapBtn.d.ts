export declare const SubmitSwapBtn: ({ disabled }: {
    disabled: boolean;
}) => JSX.Element;
