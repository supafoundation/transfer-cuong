export declare const SwapWarning: () => JSX.Element | null;
