export declare const SwapPriceImpactText: () => JSX.Element | null;
