export declare const HeaderLogo: ({ height }: {
    height?: number | undefined;
}) => JSX.Element | null;
