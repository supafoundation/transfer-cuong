export declare const GasBadge: ({ onClick }: {
    onClick: () => void;
}) => JSX.Element;
