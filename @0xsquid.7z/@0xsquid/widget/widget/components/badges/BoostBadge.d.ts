export declare const BoostBadge: ({ onClick }: {
    onClick: () => void;
}) => JSX.Element;
