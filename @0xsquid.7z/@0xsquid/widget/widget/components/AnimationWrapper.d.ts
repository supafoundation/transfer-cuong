interface Props {
    lottieJsonFile: object;
    animReplacement?: JSX.Element;
}
export declare const AnimationWrapper: ({ lottieJsonFile, animReplacement, }: Props) => JSX.Element;
export {};
