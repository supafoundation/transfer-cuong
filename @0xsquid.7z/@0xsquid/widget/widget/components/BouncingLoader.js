import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export const BouncingLoader = () => {
    return (_jsxs("div", Object.assign({ className: "bouncing-loader" }, { children: [_jsx("div", {}), _jsx("div", {}), _jsx("div", {})] })));
};
//# sourceMappingURL=BouncingLoader.js.map