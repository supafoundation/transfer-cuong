import type { LoadingComponentProps } from "../../core/types/components";
export declare const ExchangeRateRow: ({ isLoading }: LoadingComponentProps) => JSX.Element;
