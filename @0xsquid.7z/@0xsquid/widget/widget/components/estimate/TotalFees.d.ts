interface Props {
    label?: string;
    isFetching?: boolean;
}
export declare const TotalFees: ({ label, isFetching, }: Props) => JSX.Element;
export {};
