import type { LoadingComponentProps } from "../../core/types/components";
export declare const ServiceFees: ({ isLoading }: LoadingComponentProps) => JSX.Element;
