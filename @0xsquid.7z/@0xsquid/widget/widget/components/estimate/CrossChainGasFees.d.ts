import type { LoadingComponentProps } from "../../core/types/components";
export declare const CrossChainGasFees: ({ isLoading }: LoadingComponentProps) => JSX.Element;
