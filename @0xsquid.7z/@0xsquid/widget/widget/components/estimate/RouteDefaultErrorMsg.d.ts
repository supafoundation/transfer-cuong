export declare const RouteDefaultErrorMsg: () => JSX.Element;
