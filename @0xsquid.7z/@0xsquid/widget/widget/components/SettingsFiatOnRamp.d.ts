export declare const SettingsFiatOnRamp: () => JSX.Element;
