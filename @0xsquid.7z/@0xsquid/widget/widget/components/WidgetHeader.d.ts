export declare const WidgetHeader: () => JSX.Element;
