interface Props {
    seconds: number;
}
export declare const EstimateTime: ({ seconds }: Props) => JSX.Element;
export {};
