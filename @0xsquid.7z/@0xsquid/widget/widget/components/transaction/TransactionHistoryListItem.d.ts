import type { TransactionHistoryStore } from "../../core/types/transaction";
interface Props {
    transaction: TransactionHistoryStore;
}
export declare const TransactionHistoryListItem: ({ transaction }: Props) => JSX.Element;
export {};
