export declare const TransactionConfirmView: () => JSX.Element;
