export declare const TransactionPauseView: () => JSX.Element;
