import type { TransactionParams } from "../../core/types/transaction";
import { TransactionStatus } from "../../core/types/transaction";
interface Props {
    status: TransactionStatus;
    transaction?: TransactionParams;
    loadingLabel?: string;
}
export declare const TransactionStatusElement: ({ status, transaction, loadingLabel, }: Props) => JSX.Element;
export {};
