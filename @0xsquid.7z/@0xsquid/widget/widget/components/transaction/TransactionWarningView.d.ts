export declare const TransactionWarningView: () => JSX.Element;
