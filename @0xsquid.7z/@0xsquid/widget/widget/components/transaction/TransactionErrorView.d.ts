import type { TransactionStatus } from "../../core/types/transaction";
export declare const TransactionErrorView: ({ state, }: {
    state: TransactionStatus | undefined;
}) => JSX.Element;
