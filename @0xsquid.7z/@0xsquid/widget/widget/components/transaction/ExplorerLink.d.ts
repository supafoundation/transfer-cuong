interface Props {
    explorerUrl: string;
    height?: number;
    externalExplorerImageUrl?: string;
}
export declare const ExplorerLink: ({ explorerUrl, height, externalExplorerImageUrl, }: Props) => JSX.Element;
export {};
