export declare const TransactionReceivedAxlUSDCView: () => JSX.Element;
