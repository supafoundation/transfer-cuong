export declare const TransactionUnknownWalletView: () => JSX.Element;
