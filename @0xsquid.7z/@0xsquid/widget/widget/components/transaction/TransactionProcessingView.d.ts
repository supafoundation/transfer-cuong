interface Props {
    setIsCollapseBoxOpen: (value: boolean) => void;
}
export declare const TransactionProcessingView: ({ setIsCollapseBoxOpen }: Props) => JSX.Element;
export {};
