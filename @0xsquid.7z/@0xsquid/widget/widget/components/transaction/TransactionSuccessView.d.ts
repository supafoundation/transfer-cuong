interface Props {
    openBox: (b: boolean) => void;
}
export declare const TransactionSuccessView: ({ openBox }: Props) => JSX.Element;
export {};
