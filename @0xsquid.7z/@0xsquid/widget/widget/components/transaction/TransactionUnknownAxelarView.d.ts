export declare const TransactionUnknownAxelarView: () => JSX.Element;
