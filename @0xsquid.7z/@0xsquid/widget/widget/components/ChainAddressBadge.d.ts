interface Props {
    walletAddress?: string;
    chainIconUrl?: string;
}
export declare const ChainAddressBadge: ({ walletAddress, chainIconUrl }: Props) => JSX.Element;
export {};
