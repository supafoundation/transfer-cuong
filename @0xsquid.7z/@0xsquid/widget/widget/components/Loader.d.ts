interface Props {
    size?: number;
}
export declare const Loader: ({ size }: Props) => JSX.Element;
export {};
