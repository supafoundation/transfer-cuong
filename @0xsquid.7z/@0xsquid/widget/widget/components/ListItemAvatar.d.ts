import React from "react";
export declare const ListItemAvatar: React.FC<any>;
