interface Props {
    showIcon?: boolean;
    className?: string;
}
export declare const GoBack: ({ showIcon, className }: Props) => JSX.Element;
export {};
