export declare const SlippageSettingsComponent: () => JSX.Element;
