export declare const MaintenanceLayout: () => JSX.Element;
