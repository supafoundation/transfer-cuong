export declare const Timer: () => JSX.Element;
