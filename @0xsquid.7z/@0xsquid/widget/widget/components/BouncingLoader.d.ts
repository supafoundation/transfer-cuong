export declare const BouncingLoader: () => JSX.Element;
