import type { ConfigTheme } from "../core/types/config";
export declare const SquidApp: ({ configStyle }: {
    configStyle?: ConfigTheme | undefined;
}) => JSX.Element;
