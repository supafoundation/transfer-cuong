import type { DefaultOptions } from "@tanstack/react-query";
export declare const DEFAULT_STALE_TIME = 8000;
export declare const defaultOptions: DefaultOptions;
