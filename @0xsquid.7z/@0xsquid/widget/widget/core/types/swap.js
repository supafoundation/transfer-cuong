export {};
//# sourceMappingURL=swap.js.map