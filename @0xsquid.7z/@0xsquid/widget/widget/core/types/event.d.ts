import type { RouteData } from "@0xsquid/sdk";
export interface WidgetEventMap {
    swapStatus: {
        status: string;
    };
    swap: {
        route: RouteData;
        txHash: string;
    };
}
export type EventListenerFunction<T extends keyof WidgetEventMap> = (event: CustomEvent<WidgetEventMap[T]>) => void;
