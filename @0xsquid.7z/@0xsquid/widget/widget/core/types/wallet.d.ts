import type { ChainType } from "@0xsquid/sdk";
import type { Chain } from "wagmi";
export type TypedWindow = Window & typeof globalThis & {
    [key in WindowWalletFlag]?: any;
};
export declare enum WindowWalletFlag {
    Binance = "bbcSignTx",
    Coinbase = "isCoinbaseWallet",
    MetaMask = "isMetaMask",
    WalletConnect = "walletConnect",
    CosmostationEVM = "cosmostation",
    CosmostationCosmos = "cosmostation.providers.keplr",
    Keplr = "keplr",
    Leap = "leap",
    Xdefi = "xfi",
    XdefiCosmos = "xfi.keplr",
    BitGet = "bitkeep",
    TrustWallet = "trustwallet",
    FetchAi = "keplr",
    Coin98 = "coin98",
    Rabby = "isRabby",
    OKX = "okxwallet",
    Injected = "injected",
    DefiConnect = "deficonnectProvider",
    Zerion = "isZerion",
    Snapper = "cosmos"
}
export type ConnectorID = "metaMask" | "walletConnect" | "coinbaseWallet" | "keplr" | "cosmostation" | "cosmostationCosmos" | "leap" | "xdefi" | "xdeficosmos" | "bitget" | "fetchai" | "coin98" | "rabby" | "okx" | "injected" | "zerion" | "deficonnect" | "snapper" | "trustwallet";
export interface Wallet {
    name: string;
    type: ChainType;
    connectorId: ConnectorID;
    connectorName: string;
    connector?: (chains?: Chain[]) => any;
    icon: string | undefined;
    windowFlag: string;
    canSwitchWallets: boolean;
    direction?: "from" | "to";
    connectedAddress?: string;
}
export interface AddEthereumChainParameter {
    chainId: string;
    chainName: string;
    nativeCurrency: {
        name: string;
        symbol: string;
        decimals: number;
        icon: string;
    };
    rpcUrls: string[];
    blockExplorerUrls?: string[];
    iconUrls?: string[];
}
