import type { ChainData, RouteData, StatusResponse, TokenData } from "@0xsquid/sdk";
import type { UseQueryResult } from "@tanstack/react-query";
import type { TransactionErrorWithMessage } from "./error";
export declare enum TransactionType {
    BRIDGE = "BRIDGE",
    BRIDGE_CALL = "BRIDGE_CALL",
    CALL_BRIDGE = "CALL_BRIDGE",
    CALL_BRIDGE_CALL = "CALL_BRIDGE_CALL"
}
export declare enum AxelarStatusResponseType {
    GAS_PAID_NOT_ENOUGH_GAS = "gas_paid_not_enough_gas",
    DESTINATION_EXECUTED = "destination_executed",
    EXPRESS_EXECUTED = "express_executed",
    CROSS_MULTICALL_EXECUTED = "CrossMulticallExecuted",
    CROSS_MULTICALL_FAILED = "CrossMulticallFailed",
    SRC_GATEWAY_CALLED = "source_gateway_called",
    DEST_GATEWAY_APPROVED = "destination_gateway_approved",
    DESTINATION_EXECUTE_ERROR = "destination_execute_error",
    DESTINATION_EXECUTING = "executing",
    UNKNOWN_ERROR = "unknown_error",
    CANNOT_FETCH_STATUS = "cannot_fetch_status",
    ERROR = "error"
}
export declare enum TransactionStatus {
    SUCCESS = "success",
    NEEDS_GAS = "needs_gas",
    ONGOING = "ongoing",
    PARTIAL_SUCCESS = "partial_success",
    NOT_FOUND = "not_found",
    INITIAL_LOADING = "initialLoading",
    ERROR = "error",
    WARNING = "warning",
    PENDING = "pending",
    REJECTED = "rejected"
}
export interface TransactionParams {
    routeType: string;
    fromChain?: ChainData;
    toChain?: ChainData;
    nonce?: number;
    transactionId: string | undefined;
    timestamp?: number;
    sourceStatus?: TransactionStatus;
    status: TransactionStatus;
    error?: TransactionErrorWithMessage;
    fromAddress?: string;
    statusResponse?: StatusResponse;
    axelarUrl?: string;
    sourceTxExplorerUrl?: string;
    sourceExplorerImgUrl?: string;
}
export type TransactionHistoryStore = TransactionParams & Pick<RouteData, "params">;
export interface TransactionStepsProps {
    currentTransaction?: TransactionParams;
    sourceExplorerUrl?: string;
    fromToken?: TokenData;
    toToken?: TokenData;
    toChain?: ChainData;
    fromChain?: ChainData;
}
export type TransactionStepProps = TransactionStepsProps & {
    statusResponse?: UseQueryResult<StatusResponse, unknown>;
};
export interface StepStatusGetterProps {
    transaction?: TransactionParams;
    statusResponse?: UseQueryResult<StatusResponse, unknown>;
    onlyFullStatusStep?: boolean;
}
