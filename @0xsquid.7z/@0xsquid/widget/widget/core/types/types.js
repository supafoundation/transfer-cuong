// TODO: BELOW Are temporary types taken from api for development because SDK wasn't up to date
export var FeeType;
(function (FeeType) {
    FeeType["AXELAR_FEE"] = "Axelar Fee";
    FeeType["GAS_RECEIVER_FEE"] = "Cross-chain gas fees";
})(FeeType || (FeeType = {}));
//# sourceMappingURL=types.js.map