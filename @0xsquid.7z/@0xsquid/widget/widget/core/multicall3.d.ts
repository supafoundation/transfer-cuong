export declare const multicallAddress = "0xcA11bde05977b3631167028862bE2a173976CA11";
export declare const multicallAbi: {
    inputs: {
        internalType: string;
        name: string;
        type: string;
    }[];
    name: string;
    outputs: {
        internalType: string;
        name: string;
        type: string;
    }[];
    stateMutability: string;
    type: string;
}[];
