export declare const checkMarkInfo: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: ({
                        i: {
                            x: number;
                            y: number;
                        };
                        o: {
                            x: number;
                            y: number;
                        };
                        t: number;
                        s: number[];
                        to: number[];
                        ti: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                        to?: undefined;
                        ti?: undefined;
                    })[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                r?: undefined;
                bm?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                s?: undefined;
                e?: undefined;
                o?: undefined;
                m?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                e: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                m: number;
                ix: number;
                nm: string;
                mn: string;
                hd: boolean;
                ind?: undefined;
                ks?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                s?: undefined;
                e?: undefined;
                m?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                e?: undefined;
                m?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                e?: undefined;
                o?: undefined;
                m?: undefined;
                ix?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                s: {
                    a: number;
                    k: number;
                    ix: number;
                };
                e: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                m: number;
                ix: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                p?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                e?: undefined;
                m?: undefined;
                ix?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                e?: undefined;
                m?: undefined;
                ix?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    })[];
    markers: never[];
};
export declare const checkMarkSuccess: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                s?: undefined;
                e?: undefined;
                o?: undefined;
                m?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                e: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                m: number;
                ix: number;
                nm: string;
                mn: string;
                hd: boolean;
                ind?: undefined;
                ks?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                s?: undefined;
                e?: undefined;
                m?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                e?: undefined;
                m?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                e?: undefined;
                o?: undefined;
                m?: undefined;
                ix?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                s: {
                    a: number;
                    k: number;
                    ix: number;
                };
                e: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                m: number;
                ix: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                p?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                e?: undefined;
                m?: undefined;
                ix?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                e?: undefined;
                m?: undefined;
                ix?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    })[];
    markers: never[];
};
export declare const checkMarkError: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                s?: undefined;
                e?: undefined;
                o?: undefined;
                m?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                e: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                m: number;
                ix: number;
                nm: string;
                mn: string;
                hd: boolean;
                ind?: undefined;
                ks?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                s?: undefined;
                e?: undefined;
                m?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                e?: undefined;
                m?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                e?: undefined;
                o?: undefined;
                m?: undefined;
                ix?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                s: {
                    a: number;
                    k: number;
                    ix: number;
                };
                e: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                m: number;
                ix: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                p?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                e?: undefined;
                m?: undefined;
                ix?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                e?: undefined;
                m?: undefined;
                ix?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    })[];
    markers: never[];
};
export declare const loadingDots: {
    v: string;
    meta: {
        g: string;
        a: string;
        k: string;
        d: string;
        tc: string;
    };
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                r?: undefined;
                bm?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                r?: undefined;
                bm?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                bm?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        bm: number;
    })[];
    markers: never[];
};
export declare const transactionPendingAnimation: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                        } | {
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    s?: undefined;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ind?: undefined;
                    ks?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    s?: undefined;
                    e?: undefined;
                    m?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        hd: boolean;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                s: boolean;
                x: {
                    a: number;
                    k: number;
                    ix: number;
                };
                y: {
                    a: number;
                    k: number;
                    ix: number;
                };
                a?: undefined;
                k?: undefined;
                ix?: undefined;
                l?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        ip: number;
        op: number;
        st: number;
        bm: number;
        parent?: undefined;
        shapes?: undefined;
        ct?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                        } | {
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    s?: undefined;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ind?: undefined;
                    ks?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    s?: undefined;
                    e?: undefined;
                    m?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
        hd?: undefined;
    })[];
    markers: never[];
};
export declare const transactionProcessinganimation: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
                x?: undefined;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
                x?: undefined;
            };
            p: {
                s: boolean;
                x: {
                    a: number;
                    k: number;
                    ix: number;
                };
                y: {
                    a: number;
                    k: number;
                    ix: number;
                };
                a?: undefined;
                k?: undefined;
                ix?: undefined;
                l?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
                x?: undefined;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: ({
                        i: {
                            x: number;
                            y: number;
                        };
                        o: {
                            x: number;
                            y: number;
                        };
                        t: number;
                        s: number[];
                        to: number[];
                        ti: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                        to?: undefined;
                        ti?: undefined;
                    })[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
                x: string;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                    x: string;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
                x: string;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        hd: boolean;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
                x?: undefined;
            };
            p: {
                s: boolean;
                x: {
                    a: number;
                    k: number;
                    ix: number;
                };
                y: {
                    a: number;
                    k: number;
                    ix: number;
                };
                a?: undefined;
                k?: undefined;
                ix?: undefined;
                l?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        ip: number;
        op: number;
        st: number;
        bm: number;
        shapes?: undefined;
        ct?: undefined;
        parent?: undefined;
    })[];
    markers: never[];
};
export declare const transactionFailureAnimation: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    d: number;
                    ty: string;
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    d?: undefined;
                    p?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    d?: undefined;
                    s?: undefined;
                    p?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    d?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        ip: number;
        op: number;
        st: number;
        bm: number;
        parent?: undefined;
        shapes?: undefined;
        ct?: undefined;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    d: number;
                    ty: string;
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    d?: undefined;
                    p?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    d?: undefined;
                    s?: undefined;
                    p?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    d?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    d: number;
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    d?: undefined;
                    p?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    d?: undefined;
                    s?: undefined;
                    p?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    d?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        hd: boolean;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                    h?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        ip: number;
        op: number;
        st: number;
        bm: number;
        parent?: undefined;
        shapes?: undefined;
        ct?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    d: number;
                    ty: string;
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    d?: undefined;
                    p?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    d?: undefined;
                    s?: undefined;
                    p?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    d?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        hd: boolean;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        ip: number;
        op: number;
        st: number;
        bm: number;
        parent?: undefined;
        shapes?: undefined;
        ct?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                s: boolean;
                x: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                        h?: undefined;
                    } | {
                        t: number;
                        s: number[];
                        h: number;
                        i?: undefined;
                        o?: undefined;
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                        h?: undefined;
                    })[];
                    ix: number;
                };
                y: {
                    a: number;
                    k: number;
                    ix: number;
                };
                a?: undefined;
                k?: undefined;
                ix?: undefined;
                l?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
        hd?: undefined;
    })[];
    markers: never[];
};
export declare const transactionSuccessAnimation: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ty: string;
                    it: ({
                        ind: number;
                        ty: string;
                        ix: number;
                        ks: {
                            a: number;
                            k: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            };
                            ix: number;
                        };
                        nm: string;
                        mn: string;
                        hd: boolean;
                        p?: undefined;
                        a?: undefined;
                        s?: undefined;
                        r?: undefined;
                        o?: undefined;
                        sk?: undefined;
                        sa?: undefined;
                    } | {
                        ty: string;
                        p: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        a: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        s: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        r: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        o: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        sk: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        sa: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        nm: string;
                        ind?: undefined;
                        ix?: undefined;
                        ks?: undefined;
                        mn?: undefined;
                        hd?: undefined;
                    })[];
                    nm: string;
                    np: number;
                    cix: number;
                    bm: number;
                    ix: number;
                    mn: string;
                    hd: boolean;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    o?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: number[];
                            to: number[];
                            ti: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                            to?: undefined;
                            ti?: undefined;
                        })[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    it?: undefined;
                    np?: undefined;
                    cix?: undefined;
                    bm?: undefined;
                    ix?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ln?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: {
                        t: number;
                        s: number[];
                        h: number;
                    }[];
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                ix?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ty: string;
                    it: ({
                        ind: number;
                        ty: string;
                        ix: number;
                        ks: {
                            a: number;
                            k: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            };
                            ix: number;
                        };
                        nm: string;
                        mn: string;
                        hd: boolean;
                        s?: undefined;
                        e?: undefined;
                        o?: undefined;
                        m?: undefined;
                        p?: undefined;
                        a?: undefined;
                        r?: undefined;
                        sk?: undefined;
                        sa?: undefined;
                    } | {
                        ty: string;
                        s: {
                            a: number;
                            k: ({
                                i: {
                                    x: number[];
                                    y: number[];
                                };
                                o: {
                                    x: number[];
                                    y: number[];
                                };
                                t: number;
                                s: number[];
                            } | {
                                t: number;
                                s: number[];
                                i?: undefined;
                                o?: undefined;
                            })[];
                            ix: number;
                        };
                        e: {
                            a: number;
                            k: ({
                                i: {
                                    x: number[];
                                    y: number[];
                                };
                                o: {
                                    x: number[];
                                    y: number[];
                                };
                                t: number;
                                s: number[];
                            } | {
                                t: number;
                                s: number[];
                                i?: undefined;
                                o?: undefined;
                            })[];
                            ix: number;
                        };
                        o: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        m: number;
                        ix: number;
                        nm: string;
                        mn: string;
                        hd: boolean;
                        ind?: undefined;
                        ks?: undefined;
                        p?: undefined;
                        a?: undefined;
                        r?: undefined;
                        sk?: undefined;
                        sa?: undefined;
                    } | {
                        ty: string;
                        p: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        a: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        s: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        r: {
                            a: number;
                            k: ({
                                i: {
                                    x: number[];
                                    y: number[];
                                };
                                o: {
                                    x: number[];
                                    y: number[];
                                };
                                t: number;
                                s: number[];
                            } | {
                                t: number;
                                s: number[];
                                i?: undefined;
                                o?: undefined;
                            })[];
                            ix: number;
                        };
                        o: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        sk: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        sa: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        nm: string;
                        ind?: undefined;
                        ix?: undefined;
                        ks?: undefined;
                        mn?: undefined;
                        hd?: undefined;
                        e?: undefined;
                        m?: undefined;
                    })[];
                    nm: string;
                    np: number;
                    cix: number;
                    bm: number;
                    ix: number;
                    mn: string;
                    hd: boolean;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    o?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    it: ({
                        ind: number;
                        ty: string;
                        ix: number;
                        ks: {
                            a: number;
                            k: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            };
                            ix: number;
                        };
                        nm: string;
                        mn: string;
                        hd: boolean;
                        s?: undefined;
                        e?: undefined;
                        o?: undefined;
                        m?: undefined;
                        p?: undefined;
                        a?: undefined;
                        r?: undefined;
                        sk?: undefined;
                        sa?: undefined;
                    } | {
                        ty: string;
                        s: {
                            a: number;
                            k: ({
                                i: {
                                    x: number[];
                                    y: number[];
                                };
                                o: {
                                    x: number[];
                                    y: number[];
                                };
                                t: number;
                                s: number[];
                            } | {
                                t: number;
                                s: number[];
                                i?: undefined;
                                o?: undefined;
                            })[];
                            ix: number;
                        };
                        e: {
                            a: number;
                            k: ({
                                i: {
                                    x: number[];
                                    y: number[];
                                };
                                o: {
                                    x: number[];
                                    y: number[];
                                };
                                t: number;
                                s: number[];
                            } | {
                                t: number;
                                s: number[];
                                i?: undefined;
                                o?: undefined;
                            })[];
                            ix: number;
                        };
                        o: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        m: number;
                        ix: number;
                        nm: string;
                        mn: string;
                        hd: boolean;
                        ind?: undefined;
                        ks?: undefined;
                        p?: undefined;
                        a?: undefined;
                        r?: undefined;
                        sk?: undefined;
                        sa?: undefined;
                    } | {
                        ty: string;
                        p: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        a: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        s: {
                            a: number;
                            k: number[];
                            ix: number;
                        };
                        r: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        o: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        sk: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        sa: {
                            a: number;
                            k: number;
                            ix: number;
                        };
                        nm: string;
                        ind?: undefined;
                        ix?: undefined;
                        ks?: undefined;
                        mn?: undefined;
                        hd?: undefined;
                        e?: undefined;
                        m?: undefined;
                    })[];
                    nm: string;
                    np: number;
                    cix: number;
                    bm: number;
                    ix: number;
                    mn: string;
                    hd: boolean;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    o?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: number[];
                            to: number[];
                            ti: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                            to?: undefined;
                            ti?: undefined;
                        })[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    it?: undefined;
                    np?: undefined;
                    cix?: undefined;
                    bm?: undefined;
                    ix?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ln?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                ix?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: ({
                        i: {
                            x: number[];
                            y: number[];
                        };
                        o: {
                            x: number[];
                            y: number[];
                        };
                        t: number;
                        s: number[];
                    } | {
                        t: number;
                        s: number[];
                        i?: undefined;
                        o?: undefined;
                    })[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
    })[];
    markers: never[];
};
export declare const transactionHalfSuccessAnimation: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
    })[];
    markers: never[];
};
export declare const transactionErrorPauseAnimation: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                    h?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: {
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                r?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        }[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                    h?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                    h?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                })[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        hd: boolean;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                s: boolean;
                x: {
                    a: number;
                    k: number;
                    ix: number;
                };
                y: {
                    a: number;
                    k: number;
                    ix: number;
                };
                a?: undefined;
                k?: undefined;
                ix?: undefined;
                l?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        ip: number;
        op: number;
        st: number;
        bm: number;
        shapes?: undefined;
        ct?: undefined;
        parent?: undefined;
    })[];
    markers: never[];
};
export declare const transactionRejectedAnimation: {
    v: string;
    fr: number;
    ip: number;
    op: number;
    w: number;
    h: number;
    nm: string;
    ddd: number;
    assets: never[];
    layers: ({
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    h?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                })[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                        } | {
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: number[];
                            to: number[];
                            ti: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                            to?: undefined;
                            ti?: undefined;
                        })[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    d: number;
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            t: number;
                            s: number[];
                            h: number;
                            i?: undefined;
                            o?: undefined;
                        } | {
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                            h?: undefined;
                        } | {
                            t: number;
                            s: number[];
                            h?: undefined;
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    p: {
                        a: number;
                        k: ({
                            t: number;
                            s: number[];
                            h: number;
                            i?: undefined;
                            o?: undefined;
                            to?: undefined;
                            ti?: undefined;
                        } | {
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: number[];
                            to: number[];
                            ti: number[];
                            h?: undefined;
                        } | {
                            t: number;
                            s: number[];
                            h?: undefined;
                            i?: undefined;
                            o?: undefined;
                            to?: undefined;
                            ti?: undefined;
                        })[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                            h?: undefined;
                        } | {
                            t: number;
                            s: number[];
                            h: number;
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                            h?: undefined;
                        } | {
                            t: number;
                            s: number[];
                            h: number;
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    d?: undefined;
                    p?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    d?: undefined;
                    s?: undefined;
                    p?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    d?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    ix?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        hd: boolean;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                s: boolean;
                x: {
                    a: number;
                    k: number;
                    ix: number;
                };
                y: {
                    a: number;
                    k: number;
                    ix: number;
                };
                a?: undefined;
                k?: undefined;
                ix?: undefined;
                l?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        ip: number;
        op: number;
        st: number;
        bm: number;
        parent?: undefined;
        shapes?: undefined;
        ct?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        parent: number;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: ({
                    i: {
                        x: number[];
                        y: number[];
                    };
                    o: {
                        x: number[];
                        y: number[];
                    };
                    t: number;
                    s: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    h?: undefined;
                })[];
                ix: number;
            };
            p: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                    h?: undefined;
                })[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: ({
                    i: {
                        x: number;
                        y: number;
                    };
                    o: {
                        x: number;
                        y: number;
                    };
                    t: number;
                    s: number[];
                    to: number[];
                    ti: number[];
                    h?: undefined;
                } | {
                    t: number;
                    s: number[];
                    h: number;
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                } | {
                    t: number;
                    s: number[];
                    i?: undefined;
                    o?: undefined;
                    to?: undefined;
                    ti?: undefined;
                    h?: undefined;
                })[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                        } | {
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    c?: undefined;
                    o?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    p?: undefined;
                    a?: undefined;
                    s?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: number[];
                            to: number[];
                            ti: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                            to?: undefined;
                            ti?: undefined;
                        })[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: {
                            t: number;
                            s: number[];
                            h: number;
                        }[];
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: {
                            i: number[][];
                            o: number[][];
                            v: number[][];
                            c: boolean;
                        };
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    s?: undefined;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ind?: undefined;
                    ks?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    s?: undefined;
                    e?: undefined;
                    m?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: number[];
                            to: number[];
                            ti: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                            to?: undefined;
                            ti?: undefined;
                        })[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                it: ({
                    ind: number;
                    ty: string;
                    ix: number;
                    ks: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                        } | {
                            t: number;
                            s: {
                                i: number[][];
                                o: number[][];
                                v: number[][];
                                c: boolean;
                            }[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    nm: string;
                    mn: string;
                    hd: boolean;
                    s?: undefined;
                    e?: undefined;
                    o?: undefined;
                    m?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    s: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    e: {
                        a: number;
                        k: ({
                            i: {
                                x: number[];
                                y: number[];
                            };
                            o: {
                                x: number[];
                                y: number[];
                            };
                            t: number;
                            s: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                        })[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    m: number;
                    ix: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ind?: undefined;
                    ks?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    c: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    w: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    lc: number;
                    lj: number;
                    bm: number;
                    nm: string;
                    mn: string;
                    hd: boolean;
                    ln: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    s?: undefined;
                    e?: undefined;
                    m?: undefined;
                    p?: undefined;
                    a?: undefined;
                    r?: undefined;
                    sk?: undefined;
                    sa?: undefined;
                } | {
                    ty: string;
                    p: {
                        a: number;
                        k: ({
                            i: {
                                x: number;
                                y: number;
                            };
                            o: {
                                x: number;
                                y: number;
                            };
                            t: number;
                            s: number[];
                            to: number[];
                            ti: number[];
                        } | {
                            t: number;
                            s: number[];
                            i?: undefined;
                            o?: undefined;
                            to?: undefined;
                            ti?: undefined;
                        })[];
                        ix: number;
                    };
                    a: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    s: {
                        a: number;
                        k: number[];
                        ix: number;
                    };
                    r: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    o: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sk: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    sa: {
                        a: number;
                        k: number;
                        ix: number;
                    };
                    nm: string;
                    ind?: undefined;
                    ix?: undefined;
                    ks?: undefined;
                    mn?: undefined;
                    hd?: undefined;
                    e?: undefined;
                    m?: undefined;
                    c?: undefined;
                    w?: undefined;
                    lc?: undefined;
                    lj?: undefined;
                    bm?: undefined;
                    ln?: undefined;
                })[];
                nm: string;
                np: number;
                cix: number;
                bm: number;
                ix: number;
                mn: string;
                hd: boolean;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                o?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                it?: undefined;
                np?: undefined;
                cix?: undefined;
                bm?: undefined;
                ix?: undefined;
                mn?: undefined;
                hd?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                ty: string;
                d: number;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                ml: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                r?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                r: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                a?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                ml?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        hd?: undefined;
    } | {
        ddd: number;
        ind: number;
        ty: number;
        nm: string;
        sr: number;
        ks: {
            o: {
                a: number;
                k: number;
                ix: number;
            };
            r: {
                a: number;
                k: number;
                ix: number;
            };
            p: {
                a: number;
                k: number[];
                ix: number;
                l: number;
                s?: undefined;
                x?: undefined;
                y?: undefined;
            };
            a: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
            s: {
                a: number;
                k: number[];
                ix: number;
                l: number;
            };
        };
        ao: number;
        shapes: ({
            ty: string;
            it: ({
                ind: number;
                ty: string;
                ix: number;
                ks: {
                    a: number;
                    k: {
                        i: number[][];
                        o: number[][];
                        v: number[][];
                        c: boolean;
                    };
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                p?: undefined;
                a?: undefined;
                s?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                ind?: undefined;
                ix?: undefined;
                ks?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        } | {
            ty: string;
            it: ({
                d: number;
                ty: string;
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                nm: string;
                mn: string;
                hd: boolean;
                c?: undefined;
                o?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                c: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                w: {
                    a: number;
                    k: number;
                    ix: number;
                };
                lc: number;
                lj: number;
                bm: number;
                nm: string;
                mn: string;
                hd: boolean;
                ln: string;
                d?: undefined;
                s?: undefined;
                p?: undefined;
                a?: undefined;
                r?: undefined;
                sk?: undefined;
                sa?: undefined;
            } | {
                ty: string;
                p: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                a: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                s: {
                    a: number;
                    k: number[];
                    ix: number;
                };
                r: {
                    a: number;
                    k: number;
                    ix: number;
                };
                o: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sk: {
                    a: number;
                    k: number;
                    ix: number;
                };
                sa: {
                    a: number;
                    k: number;
                    ix: number;
                };
                nm: string;
                d?: undefined;
                mn?: undefined;
                hd?: undefined;
                c?: undefined;
                w?: undefined;
                lc?: undefined;
                lj?: undefined;
                bm?: undefined;
                ln?: undefined;
            })[];
            nm: string;
            np: number;
            cix: number;
            bm: number;
            ix: number;
            mn: string;
            hd: boolean;
        })[];
        ip: number;
        op: number;
        st: number;
        ct: number;
        bm: number;
        parent?: undefined;
        hd?: undefined;
    })[];
    markers: never[];
};
