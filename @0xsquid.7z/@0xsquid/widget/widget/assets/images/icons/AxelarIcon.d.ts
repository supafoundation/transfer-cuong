export declare const AxelarIcon: ({ height }: {
    height?: number | undefined;
}) => JSX.Element;
