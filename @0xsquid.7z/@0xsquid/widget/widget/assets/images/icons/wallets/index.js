import binance from "./binance.svg";
import bitget from "./bitget.svg";
import brave from "./brave.svg";
import coin98 from "./c98.svg";
import coinbase from "./coinbase.svg";
import cosmostation from "./cosmostation.svg";
import defiConnect from "./defiConnect.svg";
import fetchai from "./fetchai.svg";
import keplr from "./keplr.svg";
import leap from "./leap.svg";
import metamask from "./metamask.svg";
import okx from "./okx.svg";
import rabby from "./rabby.svg";
import trustwallet from "./trustwallet.svg";
import walletConnect from "./walletConnect.svg";
import injected from "./wallet_icon.svg";
import xdefi from "./xdefi.svg";
import zerion from "./zerion.svg";
export const walletIcons = {
    binance,
    metamask,
    keplr,
    walletConnect,
    coinbase,
    brave,
    leap,
    cosmostation,
    xdefi,
    bitget,
    trustwallet,
    fetchai,
    coin98,
    rabby,
    okx,
    injected,
    zerion,
    defiConnect,
};
//# sourceMappingURL=index.js.map