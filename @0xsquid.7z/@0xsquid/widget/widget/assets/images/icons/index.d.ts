export declare const uiIcons: {
    express: any;
    gas: any;
    infinite: any;
};
