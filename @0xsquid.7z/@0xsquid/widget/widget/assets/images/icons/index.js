import express from "./express.svg";
import gas from "./gas.svg";
import infinite from "./infinite.svg";
export const uiIcons = {
    express,
    gas,
    infinite,
};
//# sourceMappingURL=index.js.map