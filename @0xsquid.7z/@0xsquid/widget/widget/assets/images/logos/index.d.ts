export declare const logos: {
    squidLogoLight: any;
    squidLogoDark: any;
    axelarFull: any;
    squidFull: any;
    squidHeart: any;
    squidLogoPurple: any;
};
