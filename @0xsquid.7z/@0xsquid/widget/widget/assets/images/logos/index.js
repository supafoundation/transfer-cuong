import axelarFull from "./axelar_full.svg";
import squidFull from "./squid_full.svg";
import squidHeart from "./squid_heart.svg";
import squidLogoDark from "./squid_logo.svg";
import squidLogoLight from "./squid_logo_light.svg";
import squidLogoPurple from "./squid_logo_purple.svg";
export const logos = {
    squidLogoLight,
    squidLogoDark,
    axelarFull,
    squidFull,
    squidHeart,
    squidLogoPurple,
};
//# sourceMappingURL=index.js.map