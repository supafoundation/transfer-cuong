export declare const useTheme: () => {
    isHeaderDark: boolean;
    isGlobalDark: boolean;
};
