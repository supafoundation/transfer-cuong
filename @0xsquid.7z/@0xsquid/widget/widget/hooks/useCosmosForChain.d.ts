import type { ChainData } from "@0xsquid/sdk";
export declare const useCosmosForChain: (chainData?: ChainData) => {
    cosmosAddress: string | undefined;
};
