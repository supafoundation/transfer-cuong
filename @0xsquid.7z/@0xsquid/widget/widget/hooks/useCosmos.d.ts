/// <reference types="react" />
import type { ChainData } from "@0xsquid/sdk";
import type { Keplr, OfflineAminoSigner, OfflineDirectSigner } from "@keplr-wallet/types";
import type { Wallet } from "../core/types/wallet";
export declare const cosmosHubChainId = "cosmoshub-4";
export declare const useCosmos: () => {
    connectCosmos: import("@tanstack/react-query").UseMutationResult<void, unknown, {
        chain: ChainData;
        wallet?: Wallet | undefined;
        direction?: "from" | "to" | undefined;
    }, unknown>;
    cosmosChainId: string | undefined;
    setCosmosChainId: import("react").Dispatch<import("react").SetStateAction<string | undefined>>;
    isConnected: boolean;
    setIsConnected: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    isInstalled: boolean;
    setIsInstalled: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    clearData: () => void;
    onCosmosChainChange: (newChainId: string) => void;
    getAddress: ({ wallet, cosmosWalletObject, chainId, }: {
        wallet: Wallet;
        cosmosWalletObject: any;
        chainId: string;
    }) => Promise<string>;
    cosmosConnectedWallet: Wallet | undefined;
    keplrTypeWallet: Keplr;
    cosmosSigner: (OfflineAminoSigner & OfflineDirectSigner) | undefined;
    getCosmosAddressForChain: (chainId?: string) => Promise<string | undefined>;
    getCosmosWalletInfos: import("@tanstack/react-query").UseMutationResult<string | undefined, unknown, {
        chainId: string;
        cosmosWalletObject?: Keplr | undefined;
    }, unknown>;
    cosmosAddress: string | undefined;
};
