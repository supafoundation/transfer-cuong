import type { ChainData } from "@0xsquid/sdk";
export type TempChainOverride = ChainData & {
    sameChainSwapEnabled?: boolean;
};
export declare const useSquidChains: () => {
    supportedSourceChains: TempChainOverride[];
    supportedDestinationChains: TempChainOverride[];
    chains: TempChainOverride[];
    fuseSearchOptions: {
        isCaseSensitive: boolean;
        includeScore: boolean;
        minMatchCharLength: number;
        threshold: number;
        keys: string[];
    };
};
