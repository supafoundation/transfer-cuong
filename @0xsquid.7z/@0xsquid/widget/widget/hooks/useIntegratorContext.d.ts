export declare const useIntegratorContext: () => {
    walletHandledExternally: boolean;
    isEmbed: boolean;
    widgetInIframe: boolean;
};
