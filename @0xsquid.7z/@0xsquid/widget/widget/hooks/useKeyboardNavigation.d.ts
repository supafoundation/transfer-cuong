import type { RefObject } from "react";
type Props = {
    itemsListRef: RefObject<HTMLElement>;
    activeListItemClassName: string;
};
export declare const useKeyboardNavigation: (props?: Props) => void;
export {};
