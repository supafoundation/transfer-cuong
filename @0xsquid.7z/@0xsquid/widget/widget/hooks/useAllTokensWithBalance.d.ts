import type { TokenData } from "@0xsquid/sdk";
import type { TokenWithBalance } from "../core/types/tokens";
export declare const useAllTokensWithBalance: (direction: "from" | "to") => {
    tokensWithBalanceQuery: import("@tanstack/react-query").UseQueryResult<TokenWithBalance[], unknown>;
    getTokensWithPrices: import("@tanstack/react-query").UseQueryResult<(TokenData & {
        balance: string;
        priceUSD?: string | undefined;
        isFavorite?: boolean | undefined;
    })[], unknown>;
    tokens: TokenWithBalance[];
};
