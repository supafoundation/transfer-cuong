export declare const useUserParams: () => {
    gasEnabled: boolean | undefined;
    expressEnabled: boolean | undefined;
    expressSupportedForThisRoute: boolean;
    getGasOnDestSupportedForThisRoute: boolean;
};
