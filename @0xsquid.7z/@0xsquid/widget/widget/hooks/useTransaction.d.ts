import type { RouteData, TokenData } from "@0xsquid/sdk";
import type { TransactionReceipt } from "@ethersproject/abstract-provider";
import type { TransactionParams } from "../core/types/transaction";
export declare const useTransaction: () => {
    routeApproved: import("@tanstack/react-query").UseQueryResult<boolean, unknown>;
    approveRoute: import("@tanstack/react-query").UseMutationResult<boolean, unknown, void, unknown>;
    swapQuery: import("@tanstack/react-query").UseMutationResult<boolean | TransactionReceipt, any, RouteData | undefined, unknown>;
    currentTransaction: TransactionParams | undefined;
    fromToken: TokenData | undefined;
    toToken: TokenData | undefined;
    squidRoute: import("@tanstack/react-query").UseQueryResult<RouteData, unknown>;
    fromPrice: string | undefined;
    toPrice: number | undefined;
    toChain: import("./useSquidChains").TempChainOverride | undefined;
    fromChain: import("./useSquidChains").TempChainOverride | undefined;
    sourceExplorerUrl: string | undefined;
};
