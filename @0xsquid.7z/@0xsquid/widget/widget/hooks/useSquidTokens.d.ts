export declare const useSquidTokens: () => {
    tokens: import("@0xsquid/sdk").TokenData[];
    fuseSearchOptions: {
        isCaseSensitive: boolean;
        threshold: number;
        findAllMatches: boolean;
        includeMatches: boolean;
        keys: {
            name: string;
            weight: number;
        }[];
    };
};
