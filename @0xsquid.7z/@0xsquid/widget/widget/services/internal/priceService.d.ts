export declare const convertTokenAmountToUSD: (tokenAmount: string, priceUSD?: string) => string;
