import type { RouteData } from "@0xsquid/sdk";
import type { EventListenerFunction, WidgetEventMap } from "../../core/types/event";
declare class WidgetEvents extends EventTarget {
    /**
     * Overriding the addEventListener method to make it easier to use with typescript
     * @param type
     * @param listener
     * @param options
     */
    listenToWidget<T extends keyof WidgetEventMap>(type: T, listener: EventListenerFunction<T>, options?: boolean | AddEventListenerOptions): void;
    /**
     * Overriding the removeEventListener method to make it easier to use with typescript
     * @param type
     * @param listener
     * @param options
     */
    removeWidgetListener<T extends keyof WidgetEventMap>(type: T, listener: EventListenerFunction<T>, options?: boolean | EventListenerOptions): void;
    /**
     * Dispatch an event of the widget
     * To be listened from an integrator website
     * For example to display a success message when transaction is done
     * @param name
     * @param data
     */
    dispatch<T extends keyof WidgetEventMap>(name: T, data: WidgetEventMap[T]): void;
    /**
     * Will dispatch the main axelar status of transaction
     * This will be called every time the status is received by backend
     * (Using interval to check status)
     * @param status
     */
    dispatchSwapStatus(status: string): void;
    /**
     * Dispatch event when user executes a swap
     * Only when we have the tx hash received
     * @param route
     */
    dispatchSwapExecuteCall(route: RouteData, txHash: string): void;
}
export declare const widgetEvents: WidgetEvents;
export {};
