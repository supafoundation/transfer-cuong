import type { ChainData, TokenData } from "@0xsquid/sdk";
import type { Keplr } from "@keplr-wallet/types";
import { SecretNetworkClient } from "secretjs";
import type { TokenWithBalance } from "../../core/types/tokens";
interface SecretToken {
    name: string;
    address: string;
    code_hash: string;
    decimals: number;
    coingecko_id: string;
    axelar_denom: string;
}
export declare const SECRET_TOKENS: SecretToken[];
export declare const findSecretToken: (axlDenom: string) => SecretToken | undefined;
/**
 * Fetch secret network token balance
 * Using the permit signature, see permit function for more details
 * @param secretJS
 * @param contract
 * @param chainId
 * @param walletAddress
 * @param permit
 * @returns
 */
export declare const getTokenBalance: (secretJS: SecretNetworkClient, contract: {
    address: string;
    codeHash: string;
}, permit: any) => Promise<unknown>;
export declare const getPermit: (chainId: string, contracts: any[], address: string) => Promise<any>;
/**
 * Fetches the secret balance of the user
 * This has a different logic than the other balances because Secret network hides the balance of the user by design
 * So we need to fetch the balance in a different way
 */
export declare const SECRET_CHAIN_ID = "secret-4";
export declare const fetchSecretPrivateBalance: (chainData: ChainData, userAddress: string, token?: TokenData, keplr?: Keplr) => Promise<string>;
export declare const fetchAllSecretBalances: (chainData: ChainData, userAddress: string, keplr?: Keplr) => Promise<TokenWithBalance[]>;
export {};
