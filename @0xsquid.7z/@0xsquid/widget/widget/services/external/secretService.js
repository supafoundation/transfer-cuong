var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { StargateClient } from "@cosmjs/stargate";
import { formatUnits } from "ethers/lib/utils.js";
import { SecretNetworkClient } from "secretjs";
export const SECRET_TOKENS = [
    {
        name: "aUSDC",
        address: "secret1vkq022x4q8t8kx9de3r84u669l65xnwf2lg3e6",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 6,
        coingecko_id: "usdc",
        axelar_denom: "uusdc",
    },
    {
        name: "AXL",
        address: "secret1vcau4rkn7mvfwl8hf0dqa9p0jr59983e3qqe3z",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 6,
        coingecko_id: "axl",
        axelar_denom: "uaxl",
    },
    {
        name: "aWETH",
        address: "secret139qfh3nmuzfgwsx2npnmnjl4hrvj3xq5rmq8a0",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 18,
        coingecko_id: "eth",
        axelar_denom: "weth-wei",
    },
    {
        name: "aWBTC",
        address: "secret1guyayjwg5f84daaxl7w84skd8naxvq8vz9upqx",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 8,
        coingecko_id: "btc",
        axelar_denom: "wbtc-satoshi",
    },
    {
        name: "aWBNB",
        address: "secret19xsac2kstky8nhgvvz257uszt44g0cu6ycd5e4",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 18,
        coingecko_id: "bnb",
        axelar_denom: "wbnb-wei",
    },
    {
        name: "aBUSD",
        address: "secret1t642ayn9rhl5q9vuh4n2jkx0gpa9r6c3sl96te",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 18,
        coingecko_id: "busd",
        axelar_denom: "busd-wei",
    },
    {
        name: "aDAI",
        address: "secret1c2prkwd8e6ratk42l4vrnwz34knfju6hmp7mg7",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 18,
        coingecko_id: "dai",
        axelar_denom: "dai-wei",
    },
    {
        name: "aUNI",
        address: "secret1egqlkasa6xe6efmfp9562sfj07lq44z7jngu5k",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 18,
        coingecko_id: "uni",
        axelar_denom: "uni-wei",
    },
    {
        name: "aUSDT",
        address: "secret1wk5j2cntwg2fgklf0uta3tlkvt87alfj7kepuw",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 6,
        coingecko_id: "usdt",
        axelar_denom: "uusdt",
    },
    {
        name: "aFRAX",
        address: "secret16e230j6qm5u5q30pcc6qv726ae30ak6lzq0zvf",
        code_hash: "638a3e1d50175fbcb8373cf801565283e3eb23d88a9b7b7f99fcc5eb1e6b561e",
        decimals: 18,
        coingecko_id: "frax",
        axelar_denom: "frax-wei",
    },
    // {
    //   name: "SCRT",
    //   address: "secret1k0jntykt7e4g3y88ltc60czgjuqdy4c9e8fzek",
    //   code_hash:
    //     "af74387e276be8874f07bec3a87023ee49b0e7ebe08178c49d0a49c3c98ed60e",
    //   decimals: 6,
    //   coingecko_id: "secret",
    //   axelar_denom: "uscrt",
    // },
];
export const findSecretToken = (axlDenom) => {
    return SECRET_TOKENS.find((token) => token.axelar_denom === axlDenom);
};
/**
 * Fetch secret network token balance
 * Using the permit signature, see permit function for more details
 * @param secretJS
 * @param contract
 * @param chainId
 * @param walletAddress
 * @param permit
 * @returns
 */
export const getTokenBalance = (secretJS, contract, permit) => __awaiter(void 0, void 0, void 0, function* () {
    if (permit) {
        const msg = {
            balance: {},
        };
        const result = yield secretJS.query.compute.queryContract({
            contract_address: contract.address,
            code_hash: contract.codeHash,
            query: {
                with_permit: {
                    query: msg,
                    permit,
                },
            },
        });
        return result;
    }
    return -1;
});
export const getPermit = (chainId, contracts, address) => __awaiter(void 0, void 0, void 0, function* () {
    const contractsString = contracts.join("_");
    const permKey = `perm_${chainId}_${contractsString}_${address}`;
    let permit;
    const permitStored = window.localStorage.getItem(permKey);
    if (permitStored)
        permit = JSON.parse(permitStored);
    // Not able to fetch permit signature from local storage,
    // Ask user to sign message
    if (!permit) {
        try {
            const result = yield window.keplr.signAmino(chainId, address, {
                chain_id: chainId,
                account_number: "0",
                sequence: "0",
                fee: {
                    amount: [{ denom: "uscrt", amount: "0" }],
                    gas: "1",
                },
                msgs: [
                    {
                        type: "query_permit",
                        value: {
                            permit_name: "secret-bridge-balance",
                            allowed_tokens: contracts,
                            permissions: ["balance"],
                        },
                    },
                ],
                memo: "",
            }, {
                preferNoSetFee: true,
                preferNoSetMemo: true,
            });
            permit = {
                params: {
                    permit_name: "secret-bridge-balance",
                    allowed_tokens: contracts,
                    chain_id: chainId,
                    permissions: ["balance"],
                },
                signature: result.signature,
            };
            window.localStorage.setItem(permKey, JSON.stringify(permit));
        }
        catch (err) {
            console.log("--- PERMIT ERROR ---");
            console.log(err);
        }
    }
    return permit;
});
/**
 * Fetches the secret balance of the user
 * This has a different logic than the other balances because Secret network hides the balance of the user by design
 * So we need to fetch the balance in a different way
 */
export const SECRET_CHAIN_ID = "secret-4";
export const fetchSecretPrivateBalance = (chainData, userAddress, token, keplr) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b, _c;
    const secretToken = findSecretToken((_a = token === null || token === void 0 ? void 0 : token.address) !== null && _a !== void 0 ? _a : "");
    if (!keplr)
        return "0.0";
    // Enables app to utilize keplr's secret utilities
    yield keplr.enable(SECRET_CHAIN_ID);
    // Create a client that handles the query encryption
    const client = new SecretNetworkClient({
        url: chainData.rest,
        chainId: SECRET_CHAIN_ID,
        wallet: keplr.getOfflineSignerOnlyAmino(SECRET_CHAIN_ID),
        encryptionUtils: keplr.getEnigmaUtils(SECRET_CHAIN_ID),
        walletAddress: userAddress,
    });
    const contracts = SECRET_TOKENS.map((t) => t.address);
    const permit = yield getPermit(SECRET_CHAIN_ID, contracts, userAddress);
    const result = (yield getTokenBalance(client, {
        address: (_b = secretToken === null || secretToken === void 0 ? void 0 : secretToken.address) !== null && _b !== void 0 ? _b : "",
        codeHash: (_c = secretToken === null || secretToken === void 0 ? void 0 : secretToken.code_hash) !== null && _c !== void 0 ? _c : "",
    }, permit));
    return formatUnits(result.balance.amount, token === null || token === void 0 ? void 0 : token.decimals);
});
export const fetchAllSecretBalances = (chainData, userAddress, keplr) => __awaiter(void 0, void 0, void 0, function* () {
    if (!keplr)
        return [];
    // Enables app to utilize keplr's secret utilities
    yield keplr.enable(SECRET_CHAIN_ID);
    // Create a client that handles the query encryption
    const client = new SecretNetworkClient({
        url: chainData.rest,
        chainId: SECRET_CHAIN_ID,
        wallet: keplr.getOfflineSignerOnlyAmino(SECRET_CHAIN_ID),
        encryptionUtils: keplr.getEnigmaUtils(SECRET_CHAIN_ID),
        walletAddress: userAddress,
    });
    const contracts = SECRET_TOKENS.map((t) => t.address);
    const permit = yield getPermit(SECRET_CHAIN_ID, contracts, userAddress);
    // Fetching all balances in parallel
    const privateTokens = yield Promise.all(SECRET_TOKENS.map((token) => __awaiter(void 0, void 0, void 0, function* () {
        const result = (yield getTokenBalance(client, {
            address: token.address,
            codeHash: token.code_hash,
        }, permit));
        return {
            chainId: SECRET_CHAIN_ID,
            address: token.address,
            name: token.name,
            symbol: token.name,
            decimals: token.decimals,
            logoURI: "",
            balance: formatUnits(result.balance.amount, token === null || token === void 0 ? void 0 : token.decimals),
        };
    })));
    // Use Stargate getBalance for SCRT
    const stargateClient = yield StargateClient.connect(chainData.rpc);
    const publicTokenBalance = yield stargateClient.getBalance(userAddress, "uscrt");
    return [
        ...privateTokens,
        {
            chainId: "secret-4",
            address: "uscrt",
            name: "Secret Network",
            symbol: "SCRT",
            decimals: 6,
            logoURI: "https://s2.coinmarketcap.com/static/img/coins/64x64/5604.png",
            coingeckoId: "secret",
            ibcDenom: "uscrt",
            balance: formatUnits(publicTokenBalance.amount, 6),
        },
    ];
});
//# sourceMappingURL=secretService.js.map