export declare const SettingsView: () => JSX.Element;
