export declare const TransactionView: () => JSX.Element;
