export declare const TransactionProgressView: () => JSX.Element;
