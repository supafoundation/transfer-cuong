export declare const DestinationAddressView: () => JSX.Element;
