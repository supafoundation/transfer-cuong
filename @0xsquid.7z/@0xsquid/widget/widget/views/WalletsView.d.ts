export declare const WalletsView: () => JSX.Element;
