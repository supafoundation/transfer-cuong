export declare const HistoryView: () => JSX.Element;
