export declare const SwapView: () => JSX.Element;
