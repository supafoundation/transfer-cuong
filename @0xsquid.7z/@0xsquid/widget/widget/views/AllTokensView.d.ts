export declare const AllTokensView: () => JSX.Element;
