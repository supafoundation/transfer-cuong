export declare const ChainsView: () => JSX.Element;
