export declare const SwapViewDetailsCollapsed: ({ isHighlightedExpress, isHighlightedGas, }: {
    isHighlightedExpress: boolean;
    isHighlightedGas: boolean;
}) => JSX.Element;
