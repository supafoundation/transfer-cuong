export declare const TokensView: () => JSX.Element;
