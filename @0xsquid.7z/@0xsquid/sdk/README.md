# 0xSquid SDK

[![Unit Tests](https://github.com/0xsquid/squid-sdk/workflows/Unit%20Tests/badge.svg)](https://github.com/0xsquid/squid-sdk/actions?query=workflow%3A%22Unit+Tests%22)
[![Lint](https://github.com/0xsquid/squid-sdk//workflows/Lint/badge.svg)](https://github.com/0xsquid/squid-sdk/actions?query=workflow%3ALint)
[![code style: prettier](https://img.shields.io/badge/code_style-prettier-ff69b4.svg?style=flat-square)](https://github.com/prettier/prettier)
[![npm version](https://img.shields.io/npm/v/@0xsquid/sdk/latest.svg)](https://www.npmjs.com/package/@0xsquid/sdk/v/latest)
[![npm bundle size (scoped version)](https://img.shields.io/bundlephobia/minzip/@0xsquid/sdk/latest.svg)](https://bundlephobia.com/result?p=@0xsquid/sdk@latest)

In-depth documentation on Squid SDK is available at [Squidrouter docs](https://docs.squidrouter.com/sdk/installing-our-sdk)
